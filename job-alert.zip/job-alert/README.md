# Daily Data Job Alerts

Runs every day on GitHub Actions (free), finds new Data Analyst / Data Science roles
open to candidates in Nigeria, filters scams and stale posts, and messages you.

## Setup (about 10 minutes)
1. Create a new GitHub repo (e.g. `job-alerts`), upload these files (keep the `.github/workflows` folder).
2. Telegram: message @BotFather -> /newbot -> copy the token. Send any message to your new bot,
   then open https://api.telegram.org/bot<TOKEN>/getUpdates and copy the number after `"chat":{"id":`.
3. Repo -> Settings -> Secrets and variables -> Actions -> add:
   - TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID
   - JOOBLE_API_KEY (optional but recommended: free key at https://jooble.org/api/about, adds Nigeria-based jobs)
   - Email instead/as well (optional): SMTP_HOST (smtp.gmail.com), SMTP_USER, SMTP_PASS (Gmail app password), EMAIL_TO
4. Actions tab -> "Daily job alerts" -> Run workflow to test. After that it runs daily at 7:00 am.

## Tuning
Edit the lists at the top of job_alert.py (titles, skills, MIN_MATCH, MIN_LEGIT, MAX_AGE_DAYS).
